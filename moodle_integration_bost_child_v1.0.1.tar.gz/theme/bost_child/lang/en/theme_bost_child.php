<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Bost Child Theme';
$string['choosereadme'] = 'Child theme for Bost, designed to inherit styles and functionality while allowing custom modifications.';
