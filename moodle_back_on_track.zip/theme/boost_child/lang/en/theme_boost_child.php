<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Boost Child Theme';
$string['choosereadme'] = 'Child theme for Boost, designed to inherit styles and functionality while allowing custom modifications.';
